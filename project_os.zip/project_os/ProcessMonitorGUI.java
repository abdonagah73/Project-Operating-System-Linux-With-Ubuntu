import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.BufferedReader;
import java.io.InputStreamReader;

public class ProcessMonitorGUI extends JFrame {

    DefaultTableModel model;
    JTable table;
    JTextField pidField;

    public ProcessMonitorGUI() {

        setTitle("Linux Process Monitor");
        setSize(1100, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        Font titleFont = new Font("Segoe UI", Font.BOLD, 18);
        Font uiFont = new Font("Segoe UI", Font.BOLD, 13);

        Color bgDark = new Color(30, 30, 45);
        Color panelDark = new Color(40, 40, 60);
        Color accent = new Color(130, 90, 255);

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(bgDark);

        JLabel title = new JLabel("Linux Process Monitoring Dashboard", JLabel.CENTER);
        title.setFont(titleFont);
        title.setForeground(Color.WHITE);
        title.setBorder(BorderFactory.createEmptyBorder(15, 0, 15, 0));
        mainPanel.add(title, BorderLayout.NORTH);

        String[] columns = {"PID", "Command", "CPU %", "Memory %", "State"};
        model = new DefaultTableModel(columns, 0);
        table = new JTable(model);
        table.setRowHeight(22);
        table.setSelectionBackground(accent);

        JScrollPane scrollPane = new JScrollPane(table);
        mainPanel.add(scrollPane, BorderLayout.CENTER);

        // -------- Controls --------
        JButton refreshBtn = new JButton("Refresh");
        JButton killBtn = new JButton("Kill (SIGTERM)");
        JButton reniceBtn = new JButton("Renice");
        JButton searchBtn = new JButton("Search PID");
        JButton showAllBtn = new JButton("Show All");

        pidField = new JTextField(8);
        pidField.setFont(uiFont);

        JButton[] buttons = {
                refreshBtn, killBtn, reniceBtn, searchBtn, showAllBtn
        };

        for (JButton b : buttons) {
            b.setBackground(accent);
            b.setForeground(Color.WHITE);
            b.setFont(uiFont);
            b.setFocusPainted(false);
        }

        JPanel controlPanel = new JPanel();
        controlPanel.setBackground(panelDark);
        controlPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        controlPanel.add(new JLabel("PID:"));
        controlPanel.add(pidField);
        controlPanel.add(searchBtn);
        controlPanel.add(showAllBtn);
        controlPanel.add(refreshBtn);
        controlPanel.add(killBtn);
        controlPanel.add(reniceBtn);

        mainPanel.add(controlPanel, BorderLayout.SOUTH);
        add(mainPanel);

        // -------- Actions --------
        refreshBtn.addActionListener(e -> loadProcesses());
        showAllBtn.addActionListener(e -> loadProcesses());
        searchBtn.addActionListener(e -> searchByPID());
        killBtn.addActionListener(e -> killProcess());
        reniceBtn.addActionListener(e -> reniceProcess());

        Timer timer = new Timer(3000, e -> loadProcesses());
        timer.start();

        loadProcesses();
    }

    // -------- Core Logic --------
    private void loadProcesses() {
        model.setRowCount(0);
        try {
            Process process = Runtime.getRuntime().exec(
                    "ps -eo pid,comm,%cpu,%mem,state --sort=-%cpu");

            BufferedReader reader =
                    new BufferedReader(new InputStreamReader(process.getInputStream()));

            reader.readLine();
            String line;

            while ((line = reader.readLine()) != null) {
                String[] data = line.trim().split("\\s+", 5);
                model.addRow(data);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void searchByPID() {
        String pid = pidField.getText().trim();
        if (pid.isEmpty()) return;

        model.setRowCount(0);
        try {
            Process process = Runtime.getRuntime().exec(
                    "ps -p " + pid + " -o pid,comm,%cpu,%mem,state");

            BufferedReader reader =
                    new BufferedReader(new InputStreamReader(process.getInputStream()));

            reader.readLine();
            String line;

            if ((line = reader.readLine()) != null) {
                String[] data = line.trim().split("\\s+", 5);
                model.addRow(data);
            } else {
                JOptionPane.showMessageDialog(this,
                        "No process found with PID " + pid);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void killProcess() {
        int row = table.getSelectedRow();
        if (row == -1) return;

        String pid = model.getValueAt(row, 0).toString();
        try {
            Runtime.getRuntime().exec("kill -15 " + pid);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void reniceProcess() {
        int row = table.getSelectedRow();
        if (row == -1) return;

        String pid = model.getValueAt(row, 0).toString();
        String niceValue = JOptionPane.showInputDialog(
                this, "Enter nice value (-20 to 19):");

        if (niceValue == null) return;

        try {
            Runtime.getRuntime().exec("renice " + niceValue + " -p " + pid);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() ->
                new ProcessMonitorGUI().setVisible(true)
        );
    }
}
