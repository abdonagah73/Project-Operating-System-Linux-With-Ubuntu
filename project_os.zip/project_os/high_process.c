#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <signal.h>
#include <stdlib.h>

void handle_sigterm(int sig) {
    printf("\nReceived SIGTERM. Cleaning up and exiting...\n");
    exit(0);
}

int main() {

pid_t pid = fork();

if (pid == 0) {

        signal(SIGTERM, handle_sigterm);
printf("\nChild\n");
printf("\nCPU Process is Looping Time...\n");
printf("\nCPU Process is Doesn't Stop...\n");
printf("\n PID = %d\n", getpid());
printf("\n PPID = %d\n", getppid());
printf("\n");
while (1) {

}
} else if (pid > 0) {

printf("\nParent\n");
printf("\nCPU Parent is Sleeping...\n");
printf("\n PID = %d\n", getpid());
printf("\n PPID = %d\n", getppid());
printf("\n");

sleep(60);
        
    } 
    
else {
        perror("fork failed");
    }
    
return 0;
}



  
