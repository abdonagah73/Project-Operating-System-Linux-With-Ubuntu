#!/bin/bash

while true; do
echo "1) Show processes"
echo "2) Run high process"
echo "3) Run Slow Process"
echo "4) Run Zombie Process"
echo "5) Run Threads"
echo "6) Renice process"
echo "7) Kill process"
echo "8) Exit"
read choice

case $choice in
1) ps -eo pid,ppid,stat,ni,%cpu,%mem,cmd ;;
2) ./project_os/high_process & ;;
3) ./project_os/slow_process & ;;
4) ./project_os/zombie_process & ;;
5) ./project_os/threaded & ;;
6) echo "PID:"; read p; echo "Nice:"; read n; renice $n $p ;;
7) echo "PID:"; read p; kill $p ;;
8) exit ;;
esac
done
