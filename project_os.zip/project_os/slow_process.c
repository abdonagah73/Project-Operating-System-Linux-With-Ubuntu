#include <stdio.h>
#include <unistd.h>
#include <signal.h>

void handle_sigterm(int sig) {
    printf("\nKill With SIGTERM.\nExiting Successfully...\n");
    _exit(0);
}

int main() {
    signal(SIGTERM, handle_sigterm);



pid_t pid = fork();

if (pid == 0) {
printf("\nSlow process started...\n");
printf("\n PID = %d\n", getpid());
printf("\n PPID = %d\n", getppid());
while (1) {
printf("\nSleeping...\n");
sleep(2);
    }
    } 
    else {
        sleep(60);
    }

    return 0;
}
