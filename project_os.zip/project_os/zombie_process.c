#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <signal.h>
#include <stdlib.h>

void handle_sigterm(int sig) {
    printf("\nReceived SIGTERM. Cleaning up and exiting...\n");
    exit(0);
}

int main() {
    pid_t pid = fork();

    if (pid == 0) {
    
     signal(SIGTERM, handle_sigterm);
     
        printf("\nChild zombie...\n");
        exit(0);
    } else {
        printf("\nParent sleeping\n");
        printf("\n PID = %d\n", getpid());
        printf("\n PPID = %d\n", getppid());
        printf("\nchild becomes zombie\n");
        sleep(60);
    }

    return 0;
}


